# Handoff: "Mike's Dads" — OSRS Group Ironman Tracker (Clog · Gear · DPS)

## Overview
A private **desktop web app** for one 5-person Old School RuneScape Group Ironman team. **Desktop-only is the shipping target** — the group decided it will never be used on mobile. Build `prototype/Iron Council Web.dc.html` (desktop). The earlier mobile prototype (`Iron Council.dc.html`) remains in the folder as design history only. Three pillars, four tabs:

1. **Home** — the group collection log gamified into a dashboard (group slot count, "green watch", page×member comparison grid, latest drops).
2. **Log** — per-boss detail: every item × every member, who owns what, KC per member.
3. **Gear** — "Gear Map": full best→worst equipment ladders per slot per combat style, generated from real wiki stats, with owned/goal states.
4. **DPS** — a full loadout builder: pick equipment per slot, compute real DPS against any monster in the game, presets of currently-owned gear per member, saveable custom presets.

The interactive desktop prototype (`prototype/Iron Council Web.dc.html`) is the source of truth for look, behavior, and math. `prototype/Concept Layouts.dc.html` is the exploration history (9 rounds of concepts) — useful context, not spec. `original-product-spec.md` is the group's original product doc; **where this README and the prototype differ from it, the prototype wins** (the app was refocused mid-project from a goals/races app onto the three pillars above; races/bounties/trophy-room concepts were explored and shelved — see Concept Layouts turns 2–5).

## About the Design Files
The files in `prototype/` are **design references created in HTML** — working prototypes showing intended look and behavior, not production code to copy directly. The task is to **recreate them in your target codebase's environment** (React/Vue/Svelte, etc.) using its established patterns. If no environment exists yet, a plain React SPA is fine — no PWA/mobile scaffolding needed. Open `Iron Council Web.dc.html` in a browser to interact with it; it fetches the live wiki dataset on load.

## Fidelity
**High-fidelity.** Colors, type, spacing, copy, and interaction details are intentional — recreate pixel-close. The DPS math is a real reference implementation (formulas below), not fake numbers. Sample data (members, ownership, clog counts) is placeholder until real API sync is wired.

## App Shell (desktop)
- Dark mode only. App fills the viewport: fixed **left sidebar (224px**, bg `#1a1710`, right border `#57503f`) + scrollable main area. Main content column max-width 1180px, padding ~26px 34px.
- **Sidebar**, top to bottom: brand block (34px emblem 🛡️ in gold-bordered box + group name Pixelify Sans 700 17px gold + subtitle "Group Ironman · 5 dads" 10px muted); nav list (⌂ Home, ▦ Collection Log, 🛡️ Gear Map, 🎯 DPS Calc — 13.5px rows, radius 7; active = bg `#3a3327` + `#ff981f` weight 600 + border `#57503f`, inactive `#8a8069`, hover bg `#211d15`); pushed to bottom: member roster (9px color dot + RSN + status tag: `👑 leads` / `31d 🕸` at 55% opacity), sync meta (`day 412 · synced 4m ago ↻`), and the data-status badge (10px: `● live wiki data` green / `○ loading dataset…` / `○ sample data` muted).
- Each tab starts with a page header: title in Pixelify Sans 22px gold, right-aligned meta/controls on the same baseline.
- **Responsive floor:** two-column rows on all tabs use `flex-wrap` + min-widths (Home left ≥540px / right ≥330px; Log rail 190–240px / table ≥560px; DPS left ≥440px / loadout panel 360–470px). Grid tables use `minmax()` columns with ellipsized name cells so they degrade instead of clipping. Below ~1250px the right rails wrap under the main column — keep this behavior. All chips/buttons are `white-space:nowrap`.
- **Group name is parameterized** — current value **"Mike's Dads"** (was "Iron Council"). Swap must be trivial (single config value). Member 5's identity color is also parameterized (default `#b08cd9`; alternates offered: `#4ec9b0`, `#ff7ab8`, `#9aa7b8`).
- Emoji glyphs: use emoji-presentation forms (🛡️ 🗡️ 🏹 🔮 🎯); bare U+2694 ⚔ renders as a monochrome ✕-like glyph at small sizes — avoid it.

## Screens / Views

### 1. Home — Clog Dashboard
Two-column row (wraps below ~1250px). **Left column (flex 1.5):** stat trio + THE GRID. **Right rail (flex 1, ~370px):** green watch, goals card, latest slots.
- **Stat trio** (3 equal cards, 12px gap): group slots `214/492` (VT323 38px gold on `#312b20`), `+6 THIS WEEK` (green `#7ec84c`), `1 TO GREEN 🔥` (green-tinted card: bg `#233020`, border `#7ec84c`). Labels 10px uppercase muted, nowrap.
- **Green watch banner** (clickable → Log/Barrows): green-tinted card, dimmed item sprite 30px, copy: "**Green watch:** Barrows 23/24 — one Torag's hammers from green".
- **Goals card** (only when goals exist): titled "GROUP GOALS" (10px orange), 11px chips with dashed gold border, 17px item sprite + name; click opens item sheet. Goals are added from Gear/DPS ("＋ goal").
- **THE GRID** — the centerpiece. Table: header row `THE GRID · slots per page` + 5 member-initial columns (`minmax(40px,54px)` each, colored per member; crown emoji on leader, cobweb on stale member at 60% opacity). One row per clog page: page name (ellipsized, `minmax(120px,1fr)`) + group count in VT323 16px (color = completion tier: green ≥90%, gold, orange, red), then per-member slot counts (VT323 16px; **green = personal best on that page**, `#57503f` for zero, member 5 column always 60% opacity). Alternating row bg `#2a2419`. Rows click → Log with that boss selected. Footer strip explains the color coding.
- **Latest slots feed** (right rail card): rows of 26px sprite + "**Name** · Item `1/512`" (rate in VT323 red) + relative time right-aligned.

### 2. Log — Per-Boss Collection Log
- Page header: title + `missing only ◻/◼` toggle (blue `#6fb3d2`); **structure banner** below (dashed border, 11px): explains this is 5 of 100+ pages; full log structure (~1,600 slots) generates from the wiki's collection-log index, ownership comes from each member's TempleOSRS sync.
- Two-column row: **vertical boss rail** (left, 190–240px card): one row per page — 24px sprite + name + group count (VT323, right-aligned); active = orange border on `#3a3327`, inactive 75% opacity.
- **Boss panel** (right, ≥560px): header (boss name Pixelify 17px gold, group count VT323 green, group KC right); **PERSONAL KC row** (per-member KC in member colors, VT323 15px); **item rows**: grid `30px | minmax(110px,1fr) | 5×minmax(44px,64px)` — 24px sprite (grayscale+55% brightness when nobody owns), item name (muted when unowned), drop rate (VT323 red), `new!` flag (green, row bg `#2d3320`), then 5 owner dots (`●` in member color / `·` in `#57503f`). Click row → **item sheet**.
- **Staleness note**: member-color dot + "Grit synced 31d ago — dots may be missing. how to sync →" (gentle, never shaming — hard rule from the spec).

### 3. Gear — Gear Map (atlas)
- **Style tabs** in the page header: 🗡️ Melee / 🏹 Ranged / 🔮 Magic (active orange, nowrap, container wraps).
- **Slot chips**: All + Weapon/Head/Cape/Neck/Ammo/Body/Shield/Legs/Hands/Feet/Ring — filters the strips.
- **One strip per slot** (11 total): header `SlotName · top 12 of N (wiki stats) · best → worst` + `x/12 owned`; cells **wrap to full width** (no horizontal scroll on desktop), 82px item cells with 30px sprites, **best → worst reading order**. Cell states:
  - **Owned**: bg `#233020`, solid green border, ✓ badge (12px green circle, top-right, overhanging −5px), owner dots (4px, member colors) under the label.
  - **Goal**: dashed gold border, GOAL badge (gold, 6px caps), sprite at `grayscale(.4)`, gold label.
  - **Missing**: 55% opacity, sprite `grayscale(.85) brightness(.75)`, muted label.
  - **2h** corner tag (6px, top-left) on two-handed weapons.
- Cell tap → item sheet. Ladder contents are **generated, not curated**: rank = `2×offensive_stat + 3×strength_bonus` for the style (see Data Integration), junk-filtered, deduped by base name + identical stats, top 12 kept.

### 4. DPS — Loadout Builder
Page header meta: `ranged 90 · rapid · no boosts`. Two-column row: **calculator column** (left, ≥440px) and **loadout panel** (right card, 360–470px).
- **Calculator column**, top to bottom: monster search input (`🔍 Search all 2,853 monsters…`; ≥2 chars opens a dropdown, max 25 results ranked by match position then label length, showing `Name (version)` + `lvl X · Y hp`); quick chips (Vorkath, Zulrah, Graardor, Kree'arra, Hydra); **readout row** — main card (gold border, gradient bg): `DPS vs <Monster>` label, DPS in VT323 58px green, `max X · acc Y% · Zt` subline, **delta line vs the active preset** (`▲ +12% vs Bert preset` green / `▼` red / neutral when unchanged); side card (170px): KILL TIME in VT323 38px (`hp / dps`, m:ss) + `Y hp · lvl X`; warning banner; best-upgrade bar; footnote.
- **Loadout panel** (right card): `PRESETS` chips row at top — Sasq / Bert / Tuna / Mage / Grit / Group / BiS, then user-saved chips (`★ name`, gold-tinted; ✕ delete affordance visible when active), then `＋ save` (dashed blue); below it the slot grid. Preset semantics:
  - **Member presets**: best owned item per slot for that member (ownership map), stat-ranked; ammo matched to weapon type.
  - **Group**: best owned by anyone.
  - **BiS**: armour stat-ranked; **weapon+ammo chosen by computed DPS against the currently selected monster** (iterate top 12 weapon candidates, pair each with its best ammo, keep the highest DPS — this is what makes t-bow win on high-magic targets and dhcb win on dragons).
  - **Saved**: user snapshots (see State).
- **Loadout grid**: 3-column grid of 11 slot cells (min-height 72px, cell bg `#211d15`): slot name (8.5px caps muted), item sprite 28px, item name (8.5px, **green if owned, gold if not owned**, ellipsized). Empty cell: dashed border, `+` mark. Disabled states: shield cell shows "2h weapon" (dashed, 55% opacity, non-interactive) when a two-handed weapon is equipped; ammo cell shows "darts (built-in)" for the blowpipe. Legend line below: "click a slot to browse alternatives · green = owned · gold = not owned yet".
- **Warning banner** (dashed orange) when applicable: "no ranged weapon in this loadout" / "no arrows equipped — ammo adds most of your ranged strength".
- **Slot picker** (right-side slide-over panel, 440px wide, full height, gold left border, scrim behind): title = slot name + `· Δdps vs current loadout · <Monster>`; rows = top 20 items for that slot (junk-filtered, deduped, ammo filtered to the weapon's ammo type): 28px sprite, name (orange = currently equipped, green = owned, cream = unowned), sub `category · not owned`, owner dots, and **per-row Δdps** (VT323 17px: `+0.42` green / `−0.13` red / `·` for current). Non-weapon slots get an "— unequip —" row. Clicking applies and closes. Equipping a 2h weapon clears the shield; changing ammo type clears incompatible ammo.
- **Best single upgrade bar** (gold border): scans every slot's top 8 unowned candidates, shows the one with the highest Δdps (`Best single upgrade: <Item> +1.24 dps`, `slot · vs Monster`) + `＋ goal` button.
- **Footnote** (9px muted): formula assumptions + dataset counts.

### Item sheet (shared, Log + Gear + Home goals)
Centered modal (440px, gold border, radius 10, scrim behind): 62px framed sprite, item name (Pixelify 19px gold), source + drop rate, "Owned by: <names / nobody yet>", two buttons: `＋ Add as goal` (gold; toggles to green `✓ goal set — tap to remove`) and `mark owned (bank)` (stub — manual ownership override for banked items). The save-preset dialog is the same pattern (400px, name input + Save/Cancel).

## Interactions & Behavior
- Tab switching preserves each tab's state (boss selection, style/slot filters, loadout).
- Cross-links: Home grid row → Log (boss preselected); green-watch banner → Log/Barrows; goal additions surface as Home chips.
- Hover: rows and chips brighten (`filter:brightness(1.15)` or bg shift to `#3a3327`); nav rows get bg `#211d15`; everything clickable has `cursor:pointer`. This is a mouse-first app — hover states matter everywhere, and `title` tooltips carry full item names on truncated cells.
- Overlays: item sheet + save dialog are centered modals; slot picker is a right-side slide-over (add 200ms ease-out translate/fade in production; prototype cuts instantly). Scrim `rgba(15,13,9,.55-.65)`; click-scrim or ✕ closes.
- Loading: dataset banners per tab (`⏳ Loading …` dashed blue) + header badge; on fetch failure show dashed-red banner and degrade (Gear falls back to a small curated sample; DPS builder requires the dataset).
- Search dropdown: absolute below input, max-height 220px, scrollable.

## State Management
- `tab` · `boss` (log) · `missingOnly` · `style` + `slotFilter` (gear) · `dpsMonIdx` (selected monster) · `loadout` ({slot → item}) · `presetKey` · `pickerSlot` · `sheet` (item detail) · `goals` (list of {name, img}; seeded with Dragon hunter crossbow) · `saved` presets · `dbStatus` (loading/ready/error).
- **Saved presets persist** to localStorage key `iron-council-presets-v1`: `[{ name, items: { weapon: "Toxic blowpipe", head: "Armadyl helmet", … } }]` — item **names**, re-resolved against the equipment dataset on load (exact match, then base-name match). Same-name save overwrites. In production, sync per-user (these are per-member loadouts).
- Baseline for the DPS delta = the active preset **re-computed against the current monster** (not a stored number), so changing bosses keeps the comparison honest.

## Data Integration
**Live datasets (already wired in the prototype):**
- Monsters + equipment JSON from the OSRS Wiki's DPS-calc dataset:
  - `https://raw.githubusercontent.com/weirdgloop/osrs-dps-calc/main/cdn/json/monsters.json` (~2,850 usable monsters)
  - `.../equipment.json` (~5,300 items)
  - Fallback mirror: `https://cdn.jsdelivr.net/gh/weirdgloop/osrs-dps-calc@main/cdn/json/…`. Auto-updated upstream; cache server-side in production.
- Monster shape used: `{ name, version, level, image, skills:{hp,def,magic…}, offensive:{magic…}, defensive:{stab,slash,crush,magic,light,standard,heavy}, attributes:["dragon"…] }`. Filter out entries with `hp ≤ 0` or names starting `RuneScape:`/`Template`.
- Equipment shape used: `{ name, version, image, slot, speed, category, isTwoHanded, offensive:{ranged,magic,stab,slash,crush}, bonuses:{str,ranged_str,magic_str,prayer} }`.
- **Two-handedness is `isTwoHanded === true`** — do NOT infer from `slot` (this dataset never uses slot `'2h'`; we shipped that bug once).
- **Junk filter** (regex on name): broken/damaged/inactive/uncharged/locked/LMS/deadman/beta/bh/trailblazer/cosmetic `(g) (t) (or) (cr)`/ornament/golden/corrupted-gauntlet variants/nightmare-zone/sighted/minigame ammo (barbed, training, ogre, kebbit, bone bolts, atlatl…). Dedupe by base name (strip trailing parenthetical), keep best stats.
- Item sprites hotlinked from `https://oldschool.runescape.wiki/images/<Image_Name>.png` (spaces→underscores, URL-encode apostrophes; arrows use stacked filenames like `Dragon_arrow_5.png`). Always render with `image-rendering: pixelated`. Private group tool — hotlinking per original spec §5; don't take commercial.
- **Not yet wired** (planned per original spec §6): Wise Old Man API (levels/KC/EHB), TempleOSRS per-member collection log sync (ownership + staleness), official hiscores cross-check. All member/ownership data in the prototype is a hardcoded sample (`ownedMap` of item-name → member initials).

**DPS formulas (ranged, reference implementation in `calcLoadout`):**
- Effective ranged = `level + 8` (rapid style; level fixed at 90 in prototype — make per-member from WOM).
- Gear attack = Σ `offensive.ranged` over equipped slots; gear strength = Σ `bonuses.ranged_str` (+35 for blowpipe darts; skip shield entirely when weapon is 2h).
- `maxHit = floor(0.5 + eff × (str + 64) / 640)`; `attackRoll = eff × (att + 64)`.
- Defence roll = `(monster.def + 9) × (defBonus + 64)` where defBonus = `defensive.heavy` for crossbows, `.light` for blowpipe/thrown, `.standard` otherwise (fall back to legacy `.ranged`).
- Hit chance: `att > def ? 1 − (def+2)/(2(att+1)) : att/(2(def+1))`; `DPS = p × maxHit/2 ÷ (speed × 0.6)`, attack speed = weapon speed − 1 (rapid), floor 2 ticks.
- Specials: Twisted bow accuracy/damage scaling from target magic (cap 250, standard wiki polynomial, caps 140%/250%); Dragon hunter weapons ×1.3 accuracy ×1.25 damage vs `attributes` containing `dragon`.
- Ammo pairing: crossbows→bolts, bows→arrows, blowpipe→internal darts; warn when required ammo is missing.
- **Melee & magic loadouts are explicitly next-pass** (footnote says so); the architecture is style-agnostic — add per-style effective levels, attack-type def bonuses, and powered-staff built-in max hits.

## Design Tokens
- Background `#0f0d09` (page) / `#211d15` (app) · panels `#312b20`, `#3a3327`, sunken `#1a1710` · borders `#57503f`
- Ink `#e8dfc8` · muted `#8a8069` · disabled/zero `#57503f`
- Accent orange `#ff981f` (active nav/section heads) · gold `#f4c542` (titles, goals, emphasis) · green `#7ec84c` (owned/positive) · red `#e05b4b` (rates/negative) · blue `#6fb3d2` (links/info) · saved-preset gold-dim `#c9a227`
- Green-tint success surface `#233020`; feed-highlight `#2d3320`
- Member colors (app-wide, never repainted): S `#7ec84c` · B `#e05b4b` · T `#6fb3d2` · M `#f4c542` · member-5 configurable (default `#b08cd9`). Crown 👑 follows race winner; cobweb 🕸 + 60% opacity = stale sync.
- Type: **Pixelify Sans** (400–700) for headings/panel titles; **VT323** for all numerals/stats; system sans for body. Google Fonts. Never ship Jagex's proprietary font.
- Desktop type scale: page titles 22px, panel titles 17px, body rows 12.5–13px, chips 11–12px, micro-labels 8.5–11px, hero numerals VT323 38–58px.
- Radii: cards/panels 6–10, chips 5, modals 10. Shadows: overlays only (`0 8-12px 24-36px rgba(0,0,0,.5)`); sidebar and cards are flat.
- Scrollbars: thin styled (8px, thumb `#57503f`) — main area scrolls, sidebar is fixed.

## Assets
- Item/monster sprites: OSRS Wiki (`oldschool.runescape.wiki/images/…`), hotlinked, `image-rendering: pixelated`, dim treatment for unowned = `grayscale(.85) brightness(.75)`.
- Fonts: Pixelify Sans + VT323 (Google Fonts).
- Emblem is a placeholder ⚔ glyph — the group may supply real art; keep it swappable alongside the group name.
- No other imagery; UI chrome is pure CSS.

## Files
- `prototype/Iron Council Web.dc.html` — **the desktop prototype (source of truth — build this)**. Template = markup inside `<x-dc>`; logic = the `Component` class in the `data-dc-script` block (all data shapes, formulas, preset/picker logic live there).
- `prototype/Iron Council.dc.html` — the earlier mobile-first prototype. Superseded; kept as design history (same logic, phone shell + bottom tabs).
- `prototype/support.js` — prototype runtime only; ignore for implementation.
- `prototype/Concept Layouts.dc.html` — 9 turns of concept exploration (open in browser; newest at top). Turns 6–9 show the adopted direction; turns 2–5 (bounty board, boss buy-in, races) are shelved ideas the group may revisit.
- `original-product-spec.md` — the group's original product doc: principles (co-op first, no guilt UI, celebration matters, staleness always visible), API notes, sample data. Still authoritative for tone and out-of-scope rules; superseded on IA (and on the mobile-first assumption) by this README.
