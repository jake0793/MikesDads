# Design Handoff — OSRS Group Ironman Tracker
### For: UI/UX prototype build · From: product design session with the group · July 2026

This document is self-contained. It gives you everything decided so far: product intent, information architecture, screen-by-screen specs, visual direction, data shapes with realistic sample data, and edge states. An earlier low-fi HTML mockup exists (`iron-council-mockup.html`) — treat it as prior art for tone and layout instincts, **not** as the spec; this document supersedes it (the home screen in particular changed).

---

## 1. What this is

A private web app for one 5-person Old School RuneScape **Group Ironman** team. Group Ironman means five players share one economy: they can't trade outside the group, so their progress is collectively earned. The app is their mission control: shared goals, a merged collection log (rare-item checklist), weekly friendly races, a gear progression planner, and a trophy room of the group's history.

**Working name:** "Iron Council" — PLACEHOLDER. The group will supply their real in-game group name; design the identity so the name is easily swappable (logo lockup = name + small emblem, no name-dependent puns baked into visuals).

**Audience & context:** five friends, checked mostly **on phones**, often in short sessions ("did anything drop today?"), sometimes second-screen while playing on desktop. Ships as an **installable PWA** — design for home-screen install: standalone display, app icon, splash, safe-area insets, bottom tab navigation on mobile.

---

## 2. Design principles (settled in the product session — treat as constraints)

1. **Co-op leads, rivalry seasons it.** The group's shared goals are always the headline. Competitive elements (weekly races, crown) are present but subordinate — never the first thing on screen.
2. **A map, not marching orders.** The "bottleneck radar" shows what's blocking shared goals and who's involved, in neutral, informational tone. No "you should", no red alarms, no guilt UI. (Exception: sync staleness badges are allowed to nag gently — they're about data quality, not effort.)
3. **Celebration is a first-class function.** Drops and milestones are the emotional payload. Give them art, weight, and permanence (feed → timeline → hall of drops).
4. **Numbers wear OSRS clothing.** The audience reads game UI daily. Borrow the game's visual vocabulary (dark parchment-brown panels, gold/orange headers, green = obtained) without cloning Jagex assets.
5. **Stale data is visible, never silent.** Everything downstream of a player's sync shows freshness. A member who hasn't synced in 30 days should look visibly dusty, not wrong.
6. **No Discord, no loot politics.** The app is the destination (no share-to-Discord flows) and it never suggests who *should* get a drop.

---

## 3. Information architecture

Five top-level destinations (bottom tab bar on mobile, top nav on desktop):

1. **Home** (mission control)
2. **Goals** (list + bottleneck radar)
3. **Collection Log**
4. **Gear** (progression planner)
5. **Trophy Room** (timeline · hall of drops · yearbook)

Secondary surfaces: member profile (tap any avatar), skills/bosses comparison table (reachable from Home member section and member profile), settings (member management, race reset day, readiness template editor).

Global elements: header with group name + emblem, "last data refresh" timestamp, manual refresh action. The current weekly-race winner's avatar wears a small **crown badge everywhere it appears, app-wide**.

---

## 4. Screens

### 4.1 Home — Mission Control
Order of content, top to bottom:

1. **Shared goal bars (the headline).** Up to ~4 active goals as large progress bars. Each: goal title, % complete, one-line plain-language status naming the gap ("All base 80s — 73% · waiting on Prayer ×2"). Tap → goal detail. Empty state (no goals yet): friendly prompt "Set your first group goal" with 2–3 suggested templates.
2. **This week's races.** Two compact side-by-side leaderboards: *Clog slots gained* and *EHB gained* (EHB = "efficient hours bossed", a PvM effort metric). 5 rows each, movement arrows, current leader gets the 👑. Show reset countdown ("resets in 2d 14h"). Ties: crown is shared.
3. **Recent activity feed.** Merged stream: new collection log slots (with item sprite), level-ups, KC milestones, goal completions, race results. Newest first, ~10 items, "view all" → Trophy Room timeline.
4. **Member strip.** Five compact cards: avatar (+crown if holder), name, total level, combat level, sync-freshness badge (fresh <24 h / aging 1–7 d / stale >7 d). Tap → member profile.

### 4.2 Goals & Bottleneck Radar
- **Goal list:** active goals with progress bars; completed goals collapse into a "done" section (these also become timeline entries).
- **Goal detail:** per-member breakdown. For a skill goal: each member's current vs target. For a readiness goal: the checklist (stats + gear items) per member with met/unmet marks. For clog-page goals: the page grid with missing items. For KC goals: per-member and group KC vs target.
- **Bottleneck radar view:** across all active goals, a single "what's blocking us" summary sorted by closeness to completion — e.g. "ToA-ready: 2 items short (Bert: Herblore 72→78 · Grit: needs any trident)". Neutral tone per principle #2.
- **Creation/editing: anyone, instantly.** No approval flow. Creation is template-first: pick a type (skill threshold / content readiness / clog page / boss KC), fill 1–2 fields, done. Readiness goals start from **editable preset templates** (CG-ready, ToA-ready, CoX-ready, Nex-ready…) that the group can tweak in settings. Show a small edit-history line ("edited by MageDad · 2d ago") for accountability.

### 4.3 Collection Log
Mirrors the in-game log's mental model (the audience knows it cold):
- Category tabs (Bosses, Raids, Clues, Minigames, Other) → pages (e.g. "Zulrah") → item grid.
- Page header: group completion ("6/8 slots"), group KC.
- Item cell: sprite (grayscale/dimmed if nobody owns it), item name, owner chips (tiny colored member dots). Tap → detail: who owns it, quantities, dates obtained.
- Filters: "missing only" toggle; per-member filter.
- "Recent group drops" feed at category level.
- Per-member sync staleness surfaces here most prominently (this data comes from a manual in-game sync; see §6 caveats).

### 4.4 Gear Planner
- Selector: combat style (melee / ranged / magic) × member.
- Per equipment slot, a **ladder** of tiers (curated by the group): each rung = item, source ("Corrupted Gauntlet", "Kree'arra + 70 Ranged"). States: **owned** (all rungs at/below the member's tier), **next up** (highlighted, shows how to get it), **later** (muted).
- Tapping a rung toggles manual ownership override (auto-ownership comes from collection log sync where possible).
- **Group grid:** slots × members matrix showing each member's current tier name, color-scaled (early/mid/endgame ladder position) — answers "who's most behind on gear" at a glance.
- Ladders are editable (the group enjoys arguing about ordering — make editing pleasant, drag-to-reorder).

### 4.5 Trophy Room
Three sub-views (segmented control):
- **Timeline:** chronological, dated entries auto-generated from events (first drops, 99s, goal completions, weekly race results). Members can pin/caption favorites. **History starts at app launch** — design a nice "Day 1: tracking began" origin entry and expect the timeline to be sparse at first (empty-ish state matters).
- **Hall of Drops:** showcase wall of rarest items: large sprite, item name, who got it, date, drop rate ("1/512"). Sorted by rarity. This is the flex page — give it drama.
- **Yearbook:** fun aggregates as stat tiles: most-killed boss, total group EHB, drops per member, longest crown streak, total slots this year. Designed to grow into an annual "wrapped" recap.

### 4.6 Member profile (secondary)
Avatar + color, totals, skills/bosses table (vs group best), their clog highlights, their gear ladders, their race-win tally, sync status with "how to sync" helper.

---

## 5. Visual direction

- **Theme:** dark, warm, OSRS-inspired. Reference palette from the prior mockup (free to refine): background `#211d15`, panels `#312b20`/`#3a3327`, borders `#57503f`, ink `#e8dfc8`, muted ink `#8a8069`, accent orange `#ff981f`, gold `#f4c542`, green `#7ec84c` (owned/positive), red `#e05b4b` (rare/negative), blue `#6fb3d2`, purple `#b08cd9`.
- **Member identity colors** (used consistently app-wide for chips, dots, feed names, table headers): green, red, blue, gold, purple — one per member, assigned once, never repainted.
- **Typography:** headers may use a serif or pixel-flavored face for game feel; body stays a clean modern sans for legibility at phone sizes. Do not ship Jagex's proprietary RuneScape font — use a lookalike or a tasteful serif.
- **Item art:** OSRS Wiki hosts transparent item sprites (e.g. `https://oldschool.runescape.wiki/images/Toxic_blowpipe.png`); the prototype may hotlink them. Sprites are pixel art — render crisp (`image-rendering: pixelated`), never smooth-scaled.
- **Crown:** small, charming, unmissable on avatars; consider a subtle celebratory moment when it changes hands at weekly reset.
- Dark mode is the only mode.

---

## 6. Data: shapes, realities, sample set

The live app aggregates: **Wise Old Man API** (skills/XP/boss KC/EHB, group endpoints), **TempleOSRS API** (per-item collection log, synced by each member via a RuneLite plugin — this is manual and goes stale per member), and the **official hiscores** ("Collections Logged" total count per player, useful as a freshness cross-check). Prototype against static JSON in these shapes:

```json
{
  "group": { "name": "PLACEHOLDER", "founded": "2025-06-06", "day": 412 },
  "members": [
    { "id": 1, "rsn": "Sasquatch",  "color": "#7ec84c", "totalLevel": 1839, "combat": 118, "ehb": 412.3, "lastClogSync": "2026-07-23T09:00:00Z" },
    { "id": 2, "rsn": "BigIronBert","color": "#e05b4b", "totalLevel": 1702, "combat": 112, "ehb": 355.1, "lastClogSync": "2026-07-23T03:00:00Z" },
    { "id": 3, "rsn": "TunaGoblin", "color": "#6fb3d2", "totalLevel": 1688, "combat": 109, "ehb": 301.8, "lastClogSync": "2026-07-17T20:00:00Z" },
    { "id": 4, "rsn": "MageDad",    "color": "#f4c542", "totalLevel": 1594, "combat": 104, "ehb": 214.0, "lastClogSync": "2026-07-22T11:00:00Z" },
    { "id": 5, "rsn": "PureGrit",   "color": "#b08cd9", "totalLevel": 1391, "combat":  93, "ehb":  88.5, "lastClogSync": "2026-06-22T18:00:00Z" }
  ],
  "goals": [
    { "id": "g1", "type": "skill_threshold", "title": "All base 80s", "progress": 0.73,
      "blocking": [ { "member": 5, "detail": "Prayer 55→80" }, { "member": 4, "detail": "Attack 74→80" } ] },
    { "id": "g2", "type": "content_readiness", "title": "ToA-ready (all 5)", "progress": 0.86, "template": "toa_entry",
      "blocking": [ { "member": 2, "detail": "Herblore 72→78" }, { "member": 5, "detail": "needs any trident" } ] },
    { "id": "g3", "type": "clog_page", "title": "Green log Barrows", "progress": 0.62 },
    { "id": "g4", "type": "boss_kc", "title": "1,000 group Vorkath KC", "progress": 0.89 }
  ],
  "races": {
    "week": "2026-W30", "resetsAt": "2026-07-29T11:00:00Z",
    "clogSlots": [ { "member": 1, "gained": 3 }, { "member": 4, "gained": 2 }, { "member": 2, "gained": 1 }, { "member": 3, "gained": 0 }, { "member": 5, "gained": 0 } ],
    "ehb":       [ { "member": 2, "gained": 6.4 }, { "member": 1, "gained": 5.9 }, { "member": 3, "gained": 2.1 }, { "member": 4, "gained": 1.0 }, { "member": 5, "gained": 0 } ],
    "crownHolder": 1
  },
  "events": [
    { "at": "2026-07-23T07:12:00Z", "member": 1, "type": "clog_slot", "item": "Magic fang", "page": "Zulrah", "rate": "1/512" },
    { "at": "2026-07-23T02:40:00Z", "member": 4, "type": "level_up", "skill": "Farming", "level": 85 },
    { "at": "2026-07-22T19:03:00Z", "member": 3, "type": "kc_milestone", "boss": "Vorkath", "kc": 500 },
    { "at": "2026-07-21T21:30:00Z", "member": 2, "type": "clog_slot", "item": "Bandos chestplate", "page": "General Graardor", "rate": "1/381" },
    { "at": "2026-07-20T18:00:00Z", "type": "race_result", "week": "2026-W29", "winner": 1, "metric": "clogSlots" }
  ],
  "clogPage_example": {
    "page": "Zulrah", "groupKc": 3936, "slots": 8, "obtained": 6,
    "items": [
      { "name": "Tanzanite fang", "owners": [1, 4], "wikiSprite": "Tanzanite_fang.png" },
      { "name": "Magic fang", "owners": [1], "wikiSprite": "Magic_fang.png" },
      { "name": "Magma mutagen", "owners": [], "wikiSprite": "Magma_mutagen.png", "rate": "1/6553" }
    ]
  },
  "gearLadder_example": {
    "style": "ranged", "slot": "Weapon",
    "tiers": [
      { "item": "Rune crossbow", "source": "drop/shop" },
      { "item": "Toxic blowpipe", "source": "Zulrah" },
      { "item": "Bow of faerdhinen", "source": "Corrupted Gauntlet" },
      { "item": "Twisted bow", "source": "Chambers of Xeric" }
    ],
    "memberTier": { "1": 2, "2": 1, "3": 1, "4": 1, "5": 0 }
  }
}
```

**Realities to design for:**
- **Clog staleness is normal.** One member (PureGrit above) is 31 days stale — show it gracefully everywhere clog data appears, with a low-key "how to sync" pointer.
- **Skills/KC are near-real-time; clog is not.** Two freshness regimes coexist on the same screens.
- **Launch-day emptiness.** Timeline, races (week 1), and yearbook all start hollow. Every list needs a designed empty state, not a blank.
- **Numbers vary wildly in magnitude** (level 55 vs 13M XP vs 1/6553 drop rates) — formatting discipline matters.

---

## 7. Out of scope (do not design)

Discord integration of any kind; loot-priority/"who deserves the drop" logic; shame/negative-pressure mechanics (missed-sync banter capped at gentle dusty badges); public multi-group SaaS features (this is one group's private app; edits gated by a simple shared PIN at most); light mode; historical backfill before app launch.

---

## 8. Expected deliverables & open items

**From design:** high-fidelity interactive prototype of the five main screens + member profile, mobile-first (390 pt reference width) with a desktop layout pass; component states (goal bar, race row, item cell, ladder rung, feed entry, sync badge, crown) in fresh/aging/stale and empty/loaded variants; the crown-handoff moment; PWA icon + splash.

**Open items to leave parameterized:** the group name/emblem (placeholder "Iron Council" until the group supplies theirs — swap must be trivial); race reset day (default Wednesday); the fifth member's color if anyone objects to purple.
